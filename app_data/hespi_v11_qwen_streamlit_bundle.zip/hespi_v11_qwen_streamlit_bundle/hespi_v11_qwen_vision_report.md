# Hespi v11 Qwen Primary Label Vision Report
## Configuration
- EVAL records: `10`
- Records with an automatically detected primary label: `9`
- Requested Qwen model: `qwen3.7-plus`
- Actual model(s): `qwen3.7-plus`
- Model endpoint reachable: `True`
- Models endpoint error: ``
- Models advertised by endpoint: `qwen3.7-plus-2026-05-26, qwen3.7-plus, kimi-k2.6, glm-5.1, qwen3.7-max-2026-05-17, qwen3.7-max-preview, qwen3.7-max-2026-05-20, qwen3.7-max, qwen3.5-livetranslate-flash-realtime-2026-05-19, qwen3.5-livetranslate-flash-realtime, deepseek-v4-flash, deepseek-v4-pro, qwen-image-2.0-pro-2026-04-22, qwen3.6-27b, qwen3.5-plus-2026-04-20, qwen3.6-max-preview, qwen3.6-35b-a3b, qwen3.6-flash, qwen3.6-flash-2026-04-16, qwen3.5-omni-plus-realtime-2026-03-15, qwen3.5-omni-plus-realtime, qwen3.5-omni-plus-2026-03-15, qwen3.5-omni-plus, qwen3.5-omni-flash-realtime-2026-03-15, qwen3.5-omni-flash-realtime, qwen3.5-omni-flash-2026-03-15, qwen3.5-omni-flash, qwen3.6-plus-2026-04-02, qwen3.6-plus, wan2.7-image-pro, wan2.7-image, deepseek-v3.2, qwen-image-2.0-2026-03-03, qwen-image-2.0-pro, qwen-image-2.0-pro-2026-03-03, qwen-image-2.0, qwen3-asr-flash-2026-02-10, qwen3.5-flash-2026-02-23, qwen3.5-flash, qwen3.5-122b-a10b, qwen3.5-35b-a3b, qwen3.5-27b, qwen3-coder-next, qwen3.5-397b-a17b, qwen3.5-plus-2026-02-15, qwen3.5-plus, qwen3-asr-flash-realtime-2026-02-10, qwen3-tts-vc-2026-01-22, qwen3-tts-instruct-flash-2026-01-26, qwen3-tts-instruct-flash, qwen3-tts-vd-2026-01-26, qwen3-tts-instruct-flash-realtime-2026-01-22, qwen3-tts-instruct-flash-realtime, qwen3-tts-vd-realtime-2026-01-15, qwen3-vl-flash-2026-01-22, qwen3-max-2026-01-23, qwen-image-edit-max-2026-01-16, qwen-image-edit-max, qwen3-tts-vc-realtime-2026-01-15, qwen-image-plus-2026-01-09, qwen-plus-character, qwen-flash-character, qwen-image-max-2025-12-30, qwen-image-max, qwen-flash, z-image-turbo, qwen3-vl-plus-2025-12-19, qwen3-tts-vd-realtime-2025-12-16, qwen-image-edit-plus-2025-12-15, qwen3-omni-flash-realtime-2025-12-01, qwen3-omni-flash-2025-12-01, qwen3-livetranslate-flash-2025-12-01, qwen3-livetranslate-flash, qwen-mt-lite, qwen-plus-2025-12-01, qwen3-tts-vc-realtime-2025-11-27, qwen3-tts-flash-2025-11-27, qwen3-tts-flash-realtime-2025-11-27, qwen-vl-ocr-2025-11-20, qwen-mt-flash, ccai-pro, tongyi-tingwu-slp, qwen-image-edit-plus, qwen-image-edit-plus-2025-10-30, qwen3-asr-flash-realtime-2025-10-27, qwen3-asr-flash-realtime, qwen3-vl-flash, text-embedding-v4, qwen-image-edit, qwen3-vl-flash-2025-10-15, qwen3-tts-flash, qwen3-tts-flash-2025-09-18, qwen3-tts-flash-realtime-2025-09-18, qwen3-tts-flash-realtime, qwen3-omni-flash-realtime, qwen3-omni-flash, qwen3-omni-flash-2025-09-15, qwen3-omni-flash-realtime-2025-09-15, qwen3-omni-30b-a3b-captioner, qwen3-s2s-flash-realtime, qwen3-livetranslate-flash-realtime, qwen3-livetranslate-flash-realtime-2025-09-22, text-embedding-v3, qwen-plus-latest, qwen-plus-2025-01-25, qwq-plus-2025-03-05, qwen-mt-turbo, qwen-mt-plus, qwen-coder-plus, qwq-plus, qvq-max, qwen-omni-turbo, qwen3-8b, qwen3-30b-a3b, qwen3-235b-a22b, qwen-plus-2025-04-28, qwen3-coder-plus, qwen3-coder-480b-a35b-instruct, qwen3-235b-a22b-instruct-2507, qwen-plus-2025-07-14, qwen3-coder-plus-2025-07-22, qwen3-235b-a22b-thinking-2507, qwen3-coder-flash, qwen-vl-max, qwen3-max, qwen3-max-2025-09-23, qwen-image-plus, qwen3-vl-plus, qwen3-vl-235b-a22b-instruct, qwen3-vl-235b-a22b-thinking, qwen3-30b-a3b-thinking-2507, qwen3-30b-a3b-instruct-2507, qwen3-14b, qwen3-32b, qwen-vl-plus, qwen3-coder-plus-2025-09-23, qwen3-vl-plus-2025-09-23, qwen-plus-2025-09-11, qwen3-next-80b-a3b-thinking, qwen3-next-80b-a3b-instruct, qwen3-max-preview, qwen2-7b-instruct, qwen-max, qwen-plus, qwen-turbo`
- Text-chat preflight actual model: `qwen3.7-plus`
- Text-chat preflight error: ``
- Vision preflight occurrenceID: `http://data.biodiversitydata.nl/naturalis/specimen/L%20%200039590`
- Vision preflight status: `parsed`
- Vision preflight actual model: `qwen3.7-plus`
- Vision preflight error: ``

## Overall result
|   records |   records_with_primary_label |   nonempty_raw_outputs |   parsed_outputs |   coverage |   exact_match |   token_f1 |   qwen_transcription_gold_proxy |   tesseract_gold_proxy |   unsupported_prediction_rate |
|----------:|-----------------------------:|-----------------------:|-----------------:|-----------:|--------------:|-----------:|--------------------------------:|-----------------------:|------------------------------:|
|        10 |                            9 |                      9 |                9 |   0.784314 |      0.176471 |   0.329225 |                         0.20098 |             0.00490196 |                             0 |

## Field result
| field            |   evaluable_field_units |   coverage |   exact_match |   token_f1 |   transcription_gold_evidence_proxy |   tesseract_gold_evidence_proxy |   unsupported_prediction_rate |
|:-----------------|------------------------:|-----------:|--------------:|-----------:|------------------------------------:|--------------------------------:|------------------------------:|
| catalogNumber    |                       9 |   0.777778 |      0.111111 |   0.111111 |                            0.111111 |                       0         |                             0 |
| scientificName   |                       9 |   1        |      0.111111 |   0.588889 |                            0.574074 |                       0         |                             0 |
| recordedBy       |                       9 |   0.888889 |      0.111111 |   0.498942 |                            0.342593 |                       0.0277778 |                             0 |
| eventDate        |                       6 |   1        |      0.5      |   0.5      |                            0        |                       0         |                             0 |
| country          |                       9 |   0.777778 |      0.333333 |   0.333333 |                            0.111111 |                       0         |                             0 |
| stateProvince    |                       3 |   0.333333 |      0        |   0        |                            0        |                       0         |                             0 |
| decimalLatitude  |                       2 |   0        |      0        |   0        |                            0        |                       0         |                           nan |
| decimalLongitude |                       2 |   0        |      0        |   0        |                            0        |                       0         |                           nan |
| typeStatus       |                       2 |   1        |      0        |   0        |                            0        |                       0         |                             0 |

## Interpretation
- `qwen_transcription_gold_proxy` and `tesseract_gold_proxy` only test whether gold field values appear in the respective transcription after normalization. They are not OCR CER/WER.
- Qwen extraction metrics evaluate fields returned directly from the primary-label image. Values absent from the primary label should remain empty rather than be inferred from the full sheet.
- A strong visual model can still hallucinate fluent text. Review raw transcription, uncertain spans, and exact evidence before treating a field as supported.
