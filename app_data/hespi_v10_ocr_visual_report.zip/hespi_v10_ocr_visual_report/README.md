# Hespi v10 eval10 OCR visual report

Open `index.html` in a browser.

The report contains:

1. Ten EVAL records.
2. Hespi annotated region images.
3. OCR-focused crop images for collector, day, month, year, number, and barcode regions.
4. Side-by-side output from Tesseract, TrOCR-base, and ZXing where available.
5. Gold metadata compared with the final DeepSeek extraction.
6. CSV exports for further analysis.

The source data came from the uploaded GitHub Actions artifact:
`herbarium-scribe-hespi-v10-eval10-27202892926.zip`.
